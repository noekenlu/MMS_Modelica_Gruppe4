Bestandteile die Vorhanden sein  m�ssen inder Simulation:
	Motor
	Spannungsquelle
	Seilwinde
	Fixpunkt
	Masse
	Rollensysten(Zug nach oben oder zug nach unten)

Parameter die ver�ndert werden k�nnen:
	Masse
	Spannung
	Rollenanzahl
	Modus (An-true/Aus-false)
	Richtung (Hoch-true/ Runter-false)

Zu beginn alle Komponenten in das Feld ziehen und richtig miteinanser Verbinden (Konnektor Form und Farbe beachten).
Passende WErte f�r die Simulation eingeben.

Ein Beispile ist unter Simulation iin der Datei Flaschenzug_einfach_v2.mo zu finden.
